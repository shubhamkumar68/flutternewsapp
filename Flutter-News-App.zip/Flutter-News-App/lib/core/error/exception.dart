class CacheException implements Exception {}

class ConnectionException implements Exception {}