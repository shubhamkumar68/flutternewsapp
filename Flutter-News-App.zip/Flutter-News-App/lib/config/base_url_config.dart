class BaseUrlConfig {
  final String baseUrlDevelopment = 'https://bengkelrobot.net:8003';
  final String baseUrlProduction = 'https://newsapi.org';
}